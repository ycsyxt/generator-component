import Vue from 'vue'
import Router from 'vue-router'
Vue.use(Router)

/**
 * Note: 路由配置项
 */

// 公共路由
export const routes = [
  {
    path: '/index',
    component: (resolve) => require(['@/views/tool/gen/index'], resolve)
  },
  {
    path: '/gen/edit/:tableId(\\d+)',
    component: (resolve) => require(['@/views/tool/gen/editTable'], resolve)
  }
]

export default new Router({
  mode: 'history', // 去掉url中的#
  scrollBehavior: () => ({ y: 0 }),
  routes: routes
})
